// src/mappers/program.mapper.ts

import type { Program } from "../types/program.js";

export function mapProgram(row: any): Program {
    return {
        id: Number(row.id),

        tenantId: Number(row.tenant_id),

        bankId: Number(row.bank_id),

        name: row.name,

        financingType: row.financing_type,

        calculationMethod:
            row.calculation_method,

        minSalary: Number(row.min_salary),

        maxCustomerAge:
            Number(row.max_customer_age),

        maxCarAge:
            Number(row.max_car_age),

        allowedConditions:
            row.allowed_conditions,

        maxVehiclePrice:
            row.max_vehicle_price
                ? Number(row.max_vehicle_price)
                : null,

        interestRate:
            Number(row.interest_rate) || 0,

        profitRate:
            row.profit_rate
                ? Number(row.profit_rate)
                : null,

        maxMonths:
            Number(row.max_months) || 12,

        minMonths:
            Number(row.min_months) || 12,

        minDownPaymentPercent:
            Number(
                row.min_down_payment_percent
            ) || 0,

        maxFinanceAmount:
            row.max_finance_amount
                ? Number(row.max_finance_amount)
                : null,

        adminFeesPercent:
            Number(row.admin_fees_percent) || 0,

        salaryTransferRequired:
            Boolean(row.salary_transfer_required),

        active: Boolean(row.active),
    };
}