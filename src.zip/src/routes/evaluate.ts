import type { FastifyInstance } from "fastify";
import { db } from "../db/db.js";
import { getPrograms } from "../services/getPrograms.js";
import { compareOffers, rankOffers } from "../engine/index.js";
import { authMiddleware } from "../auth/auth.middleware.js";

export async function evaluateRoutes(fastify: FastifyInstance) {
    fastify.post<{ Body: { application_id: number } }>(
        "/evaluate",
        { preHandler: authMiddleware },
        async (req, reply) => {
            try {
                const tenantId = (req as any).tenantId;
                const { application_id } = req.body;

                // جيب كل بيانات الـ application
                const appResult = await db.query(
                    `SELECT a.*,
                  c.name, c.salary, c.job_type, c.current_liabilities,
                  c.owns_property, c.owns_car, c.salary_transfer,
                  c.birth_date,
                  v.price, v.manufacturing_year, v.condition, v.brand,
                  v.model
           FROM applications a
           JOIN customers c ON a.customer_id = c.id
           JOIN vehicles  v ON a.vehicle_id  = v.id
           WHERE a.id = $1 AND a.tenant_id = $2`,
                    [application_id, tenantId]
                );

                if (!appResult.rows[0])
                    return reply.status(404).send({ error: "Application not found" });

                const row = appResult.rows[0];

                // احسب العمر من birth_date
                const age = new Date().getFullYear() - new Date(row.birth_date).getFullYear();
                // احسب عمر السيارة
                const car_age = new Date().getFullYear() - Number(row.manufacturing_year);

                const input = {
                    age,
                    salary: Number(row.salary),
                    price: Number(row.price),
                    current_liabilities: Number(row.current_liabilities),
                    requested_down_payment: Number(row.requested_down_payment),
                    job_type: row.job_type,
                    car_age,
                    owns_property: Boolean(row.owns_property),
                    salary_transfer: Boolean(row.salary_transfer),
                    down_payment: Number(row.requested_down_payment),
                };

                const programs = await getPrograms(tenantId);
                const offers = await compareOffers(input, programs, tenantId);

                // احفظ الـ offers في الـ DB
                for (const offer of offers) {
                    await db.query(
                        `INSERT INTO offers
             (tenant_id, application_id, program_id, bank_id, status,
              installment, total_payment, finance_amount, down_payment,
              interest_rate, months, dti, risk_score, risk_level,
              affordability_score, reasons)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
                        [
                            tenantId, application_id, offer.programId, offer.bankId,
                            offer.status, offer.installment, offer.totalPayment,
                            offer.financeAmount ?? 0, input.requested_down_payment,
                            offer.interestRate, offer.months, offer.dti,
                            offer.riskScore, offer.riskLevel, offer.affordabilityScore,
                            JSON.stringify(offer.reasons ?? []),
                        ]
                    );
                }

                const approved = offers.filter(o => o.status === "APPROVED");
                const ranked = rankOffers(approved);

                return { bestOffer: ranked[0] ?? null, offers };

            } catch (err: any) {
                fastify.log.error(err);
                return reply.status(500).send({ error: err?.message });
            }
        }
    );
}