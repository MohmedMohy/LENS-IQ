import type { RuleOperator } from "../../types/rule.js";

export function applyOperator(
    fieldValue: number,
    operator: RuleOperator,
    ruleValue: number
): boolean {
    switch (operator) {
        case ">": return fieldValue > ruleValue;
        case ">=": return fieldValue >= ruleValue;
        case "<": return fieldValue < ruleValue;
        case "<=": return fieldValue <= ruleValue;
        case "=": return fieldValue === ruleValue;
        case "!=": return fieldValue !== ruleValue;
        default: return false;
    }
}