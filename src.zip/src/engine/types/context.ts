import type { ApplicationInput } from "../../types/applicationInput.js";
import type { Program } from "../../types/program.js";

export interface EvaluationContext {
    input: ApplicationInput;
    program: Program;
    rules: any[];

    baseDTI: number;
    reasons: any[];
}