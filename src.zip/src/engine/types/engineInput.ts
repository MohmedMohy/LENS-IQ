import type { ApplicationInput } from "../../types/applicationInput.js";

export type EngineInput = ApplicationInput;